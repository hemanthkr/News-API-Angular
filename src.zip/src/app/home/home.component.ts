import { Component, OnInit } from '@angular/core';
import { NewsApiService } from '../shared/services/news-api.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public mArticles: any;
  // source = 'ABC News (AU)';

  constructor(private newsapi: NewsApiService) { }

  ngOnInit() {
    this.newsapi.getTopHeadLines().subscribe(data => this.mArticles = data['articles']);

    // this.newsapi.getNewBySource(this.source).subscribe(data => this.mArticles = data['articles']);
  }

}

import { Component, OnInit } from '@angular/core';
import { NewsApiService } from './shared/services/news-api.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'news-app';

  private mArticles: any;

  constructor(private newsApi: NewsApiService, protected router: Router) { }

  ngOnInit() {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    
    this.newsApi.initArticles().subscribe(res => { 
      this.mArticles = res });
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class NewsApiService {

  api_Key = '0714e1f4a971488dbfb655cb85a7ad3b';

  constructor(private http: HttpClient) { }

  getTopHeadLines(){
    return this.http.get('https://newsapi.org/v2/top-headlines?country=in&category=sports&apiKey='+this.api_Key);
  }
  getNewBySource(source){
    return this.http.get('https://newsapi.org/v2/top-headlines?sources='+source+'&apiKey='+this.api_Key);
  }
  getSources(){
    return this.http.get('https://newsapi.org/v2/sources?apiKey='+this.api_Key);
  }


}
